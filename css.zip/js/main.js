// Menu toggle functionality
document.addEventListener('DOMContentLoaded', function() {
  const menuToggle = document.querySelector('.menu-toggle');
  const mainNav = document.querySelector('.main-nav');
  
  if (menuToggle && mainNav) {
    menuToggle.addEventListener('click', function() {
      menuToggle.classList.toggle('active');
      mainNav.classList.toggle('active');
    });
  }
  
  // Close menu when clicking on a nav link (mobile)
  const navLinks = document.querySelectorAll('.main-nav a');
  navLinks.forEach(link => {
    link.addEventListener('click', () => {
      if (mainNav.classList.contains('active')) {
        menuToggle.classList.remove('active');
        mainNav.classList.remove('active');
      }
    });
  });
  
  // Scroll animations
  const sections = document.querySelectorAll('.section');
  
  function checkSections() {
    const triggerBottom = window.innerHeight * 0.8;
    
    sections.forEach(section => {
      const sectionTop = section.getBoundingClientRect().top;
      
      if (sectionTop < triggerBottom) {
        section.style.opacity = '1';
        section.style.transform = 'translateY(0)';
      }
    });
  }
  
  // Set initial styles
  sections.forEach(section => {
    section.style.opacity = '0';
    section.style.transform = 'translateY(30px)';
    section.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
  });
  
  // Check sections on load
  window.addEventListener('load', checkSections);
  
  // Check sections on scroll
  window.addEventListener('scroll', checkSections);
  
  // Header scroll effect
  const header = document.getElementById('header');
  
  function headerScrollEffect() {
    if (window.scrollY > 100) {
      header.style.padding = '0.5rem 0';
      header.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.1)';
    } else {
      header.style.padding = '1rem 0';
      header.style.boxShadow = 'none';
    }
  }
  
  window.addEventListener('scroll', headerScrollEffect);
});